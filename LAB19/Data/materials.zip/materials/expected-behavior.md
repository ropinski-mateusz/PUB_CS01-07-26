# Oczekiwane zachowanie narzędzia

## Polityka walidacji

Domyślna polityka klasy `PasswordValidator`:

- minimum 12 znaków,
- co najmniej jedna mała litera,
- co najmniej jedna wielka litera,
- co najmniej jedna cyfra,
- co najmniej jeden znak specjalny z zestawu `!@#$%^&*`,
- hasło nie może być puste,
- hasło nie powinno zawierać spacji na początku ani na końcu.

W narzędziu CLI efektywna minimalna długość wynosi `16`, jeżeli użytkownik nie podał `--min-length`, a plik `config.json` nie definiuje `min_length`.

## Konfiguracja z pliku

Program powinien:

- automatycznie użyć lokalnego `config.json`, jeśli plik istnieje,
- pozwolić wskazać inny plik przez `--config`,
- działać z polityką wbudowaną, jeżeli lokalnego pliku nie ma,
- przyjąć wyłącznie dozwolone pola polityki,
- odrzucić niepoprawny JSON, nieznane klucze i niewłaściwe typy,
- zastosować jawne `--min-length` przed wartością `min_length` z pliku,
- w trybie `--verbose` pokazać źródło i efektywną politykę bez wyświetlania hasła,
- nie odczytywać haseł ani ścieżki pliku z hasłami z konfiguracji polityki.

Kolejność priorytetów:

```text
jawny argument CLI → config.json → wartości wbudowane
```

## Przypadki testowe

| Przypadek | Oczekiwany wynik |
|---|---|
| pusta linia | niepoprawne: hasło nie może być puste |
| `admin` | niepoprawne: zbyt krótkie i brakuje kilku wymaganych klas znaków |
| `password123` | niepoprawne: brak wielkiej litery i znaku specjalnego |
| `PASSWORD123!` | niepoprawne: brak małej litery |
| `PasswordTest!` | niepoprawne: brak cyfry |
| `Password1234` | niepoprawne: brak znaku specjalnego |
| wartość ze spacją na początku lub końcu | niepoprawne: spacje na brzegach |
| `VeryStrongPassword2026!` | poprawne |

## Zachowanie CLI

Program powinien:

- pokazać pomoc po użyciu `--help`,
- obsłużyć pojedyncze hasło testowe,
- obsłużyć plik z hasłami testowymi,
- odrzucić minimalną długość mniejszą niż `1`,
- wczytać i zweryfikować opcjonalny plik konfiguracji,
- czytelnie zgłosić brak pliku wejściowego,
- odrzucić jednoczesne użycie pojedynczego hasła i pliku, jeśli projekt przyjmuje zasadę jednego źródła danych,
- nie wypisywać haseł wprost w raporcie.

## Zachowanie modułu

Import modułu `password_validator.py` nie powinien:

- pytać użytkownika o dane,
- parsować argumentów CLI,
- czytać plików,
- wypisywać raportu,
- uruchamiać walidacji automatycznie.

Moduł powinien jedynie udostępniać klasę i logikę możliwą do użycia przez inne części programu.
